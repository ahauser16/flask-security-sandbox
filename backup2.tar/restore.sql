--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.11 (Ubuntu 14.11-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.11 (Ubuntu 14.11-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE nysdos_notaries_test;
--
-- Name: nysdos_notaries_test; Type: DATABASE; Schema: -; Owner: haus
--

CREATE DATABASE nysdos_notaries_test WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE nysdos_notaries_test OWNER TO haus;

\connect nysdos_notaries_test

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: commission_type; Type: TYPE; Schema: public; Owner: haus
--

CREATE TYPE public.commission_type AS ENUM (
    'Traditional',
    'Electronic'
);


ALTER TYPE public.commission_type OWNER TO haus;

--
-- Name: new_york_county; Type: TYPE; Schema: public; Owner: haus
--

CREATE TYPE public.new_york_county AS ENUM (
    'Albany County',
    'Allegany County',
    'Bronx County',
    'Broome County',
    'Cattaraugus County',
    'Cayuga County',
    'Chautauqua County',
    'Chemung County',
    'Chenango County',
    'Clinton County',
    'Columbia County',
    'Cortland County',
    'Delaware County',
    'Dutchess County',
    'Erie County',
    'Essex County',
    'Franklin County',
    'Fulton County',
    'Genesee County',
    'Greene County',
    'Hamilton County',
    'Herkimer County',
    'Jefferson County',
    'Kings County (Brooklyn)',
    'Lewis County',
    'Livingston County',
    'Madison County',
    'Monroe County',
    'Montgomery County',
    'Nassau County',
    'New York County (Manhattan)',
    'Niagara County',
    'Oneida County',
    'Onondaga County',
    'Ontario County',
    'Orange County',
    'Orleans County',
    'Oswego County',
    'Otsego County',
    'Putnam County',
    'Queens County',
    'Rensselaer County',
    'Richmond County (Staten Island)',
    'Rockland County',
    'Saint Lawrence County',
    'Saratoga County',
    'Schenectady County',
    'Schoharie County',
    'Schuyler County',
    'Seneca County',
    'Steuben County',
    'Suffolk County',
    'Sullivan County',
    'Tioga County',
    'Tompkins County',
    'Ulster County',
    'Warren County',
    'Washington County',
    'Wayne County',
    'Westchester County',
    'Wyoming County',
    'Yates County'
);


ALTER TYPE public.new_york_county OWNER TO haus;

--
-- Name: state; Type: TYPE; Schema: public; Owner: haus
--

CREATE TYPE public.state AS ENUM (
    'Alabama',
    'Alaska',
    'Arizona',
    'Arkansas',
    'California',
    'Colorado',
    'Connecticut',
    'Delaware',
    'Florida',
    'Georgia',
    'Hawaii',
    'Idaho',
    'Illinois',
    'Indiana',
    'Iowa',
    'Kansas',
    'Kentucky',
    'Louisiana',
    'Maine',
    'Maryland',
    'Massachusetts',
    'Michigan',
    'Minnesota',
    'Mississippi',
    'Missouri',
    'Montana',
    'Nebraska',
    'Nevada',
    'New Hampshire',
    'New Jersey',
    'New Mexico',
    'New York',
    'North Carolina',
    'North Dakota',
    'Ohio',
    'Oklahoma',
    'Oregon',
    'Pennsylvania',
    'Rhode Island',
    'South Carolina',
    'South Dakota',
    'Tennessee',
    'Texas',
    'Utah',
    'Vermont',
    'Virginia',
    'Washington',
    'West Virginia',
    'Wisconsin',
    'Wyoming'
);


ALTER TYPE public.state OWNER TO haus;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: haus
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO haus;

--
-- Name: notarial_act; Type: TABLE; Schema: public; Owner: haus
--

CREATE TABLE public.notarial_act (
    id integer NOT NULL,
    user_id integer,
    date timestamp without time zone,
    "time" time without time zone,
    act_type character varying(100),
    individual_name character varying(100),
    individual_address character varying(100),
    service_number integer,
    service_type character varying(100),
    credential_type character varying(100),
    communication_tech character varying(100),
    certification_authority character varying(100),
    verification_provider character varying(100)
);


ALTER TABLE public.notarial_act OWNER TO haus;

--
-- Name: notarial_act_id_seq; Type: SEQUENCE; Schema: public; Owner: haus
--

CREATE SEQUENCE public.notarial_act_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notarial_act_id_seq OWNER TO haus;

--
-- Name: notarial_act_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: haus
--

ALTER SEQUENCE public.notarial_act_id_seq OWNED BY public.notarial_act.id;


--
-- Name: notary_credentials; Type: TABLE; Schema: public; Owner: haus
--

CREATE TABLE public.notary_credentials (
    id integer NOT NULL,
    user_id integer,
    commission_holder_name character varying(100),
    commission_number_uid character varying(100),
    commissioned_county character varying(100),
    commission_type_traditional_or_electronic character varying(100),
    term_issue_date timestamp without time zone,
    term_expiration_date timestamp without time zone
);


ALTER TABLE public.notary_credentials OWNER TO haus;

--
-- Name: notary_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: haus
--

CREATE SEQUENCE public.notary_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notary_credentials_id_seq OWNER TO haus;

--
-- Name: notary_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: haus
--

ALTER SEQUENCE public.notary_credentials_id_seq OWNED BY public.notary_credentials.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: haus
--

CREATE TABLE public.role (
    id integer NOT NULL,
    name character varying(80)
);


ALTER TABLE public.role OWNER TO haus;

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: haus
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO haus;

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: haus
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: roles_users; Type: TABLE; Schema: public; Owner: haus
--

CREATE TABLE public.roles_users (
    user_id integer,
    role_id integer
);


ALTER TABLE public.roles_users OWNER TO haus;

--
-- Name: user; Type: TABLE; Schema: public; Owner: haus
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    email character varying,
    password character varying(255) DEFAULT ''::character varying NOT NULL,
    active boolean
);


ALTER TABLE public."user" OWNER TO haus;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: haus
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO haus;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: haus
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: notarial_act id; Type: DEFAULT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.notarial_act ALTER COLUMN id SET DEFAULT nextval('public.notarial_act_id_seq'::regclass);


--
-- Name: notary_credentials id; Type: DEFAULT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.notary_credentials ALTER COLUMN id SET DEFAULT nextval('public.notary_credentials_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: haus
--

COPY public.alembic_version (version_num) FROM stdin;
\.
COPY public.alembic_version (version_num) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: notarial_act; Type: TABLE DATA; Schema: public; Owner: haus
--

COPY public.notarial_act (id, user_id, date, "time", act_type, individual_name, individual_address, service_number, service_type, credential_type, communication_tech, certification_authority, verification_provider) FROM stdin;
\.
COPY public.notarial_act (id, user_id, date, "time", act_type, individual_name, individual_address, service_number, service_type, credential_type, communication_tech, certification_authority, verification_provider) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: notary_credentials; Type: TABLE DATA; Schema: public; Owner: haus
--

COPY public.notary_credentials (id, user_id, commission_holder_name, commission_number_uid, commissioned_county, commission_type_traditional_or_electronic, term_issue_date, term_expiration_date) FROM stdin;
\.
COPY public.notary_credentials (id, user_id, commission_holder_name, commission_number_uid, commissioned_county, commission_type_traditional_or_electronic, term_issue_date, term_expiration_date) FROM '$$PATH$$/3369.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: haus
--

COPY public.role (id, name) FROM stdin;
\.
COPY public.role (id, name) FROM '$$PATH$$/3363.dat';

--
-- Data for Name: roles_users; Type: TABLE DATA; Schema: public; Owner: haus
--

COPY public.roles_users (user_id, role_id) FROM stdin;
\.
COPY public.roles_users (user_id, role_id) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: haus
--

COPY public."user" (id, email, password, active) FROM stdin;
\.
COPY public."user" (id, email, password, active) FROM '$$PATH$$/3366.dat';

--
-- Name: notarial_act_id_seq; Type: SEQUENCE SET; Schema: public; Owner: haus
--

SELECT pg_catalog.setval('public.notarial_act_id_seq', 1, false);


--
-- Name: notary_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: haus
--

SELECT pg_catalog.setval('public.notary_credentials_id_seq', 3, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: haus
--

SELECT pg_catalog.setval('public.role_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: haus
--

SELECT pg_catalog.setval('public.user_id_seq', 21, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: notarial_act notarial_act_pkey; Type: CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.notarial_act
    ADD CONSTRAINT notarial_act_pkey PRIMARY KEY (id);


--
-- Name: notary_credentials notary_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.notary_credentials
    ADD CONSTRAINT notary_credentials_pkey PRIMARY KEY (id);


--
-- Name: role role_name_key; Type: CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_name_key UNIQUE (name);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: notarial_act notarial_act_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.notarial_act
    ADD CONSTRAINT notarial_act_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: notary_credentials notary_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.notary_credentials
    ADD CONSTRAINT notary_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: roles_users roles_users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.roles_users
    ADD CONSTRAINT roles_users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- Name: roles_users roles_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: haus
--

ALTER TABLE ONLY public.roles_users
    ADD CONSTRAINT roles_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- PostgreSQL database dump complete
--

